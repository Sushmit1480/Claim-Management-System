insert into benefits values ("B101","Coverage for COVID-19");
insert into benefits values ("B102","Coverage for hospitalization at home");