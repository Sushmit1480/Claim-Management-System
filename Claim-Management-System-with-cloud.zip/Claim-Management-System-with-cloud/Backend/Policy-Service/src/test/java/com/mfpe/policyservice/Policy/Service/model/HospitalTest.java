package com.mfpe.policyservice.Policy.Service.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalTest {

	Hospital hospital = new Hospital();
	
	@Test
	@DisplayName("Hospital Class is Loading or Not")
	void hospitalIsLoadingOrNot() {
		assertThat(hospital).isNotNull();
	}
	
	@Test
	@DisplayName("Checking if Hospital class Responding or not")
	void testingHospital() {
		Hospital hospital = new Hospital("H1", "Apollo Hospital", "Delhi");
		
		hospital.setHospitalId("H3");
		hospital.setLocation("Mumbai");
		
		assertEquals("H3", hospital.getHospitalId());
		assertEquals("Mumbai", hospital.getLocation());
	}

}
