package com.mfpe.policyservice.Policy.Service.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MemberPolicyTest {
	
	MemberPolicy memberPolicy = new MemberPolicy();

	@Test
	@DisplayName("Checking MemeberPolicy Class Loading or Not")
	void memberPolicyLoadingorNot() {
		assertThat(memberPolicy).isNotNull();
	}
	
	@Test
	@DisplayName("MemberPolicy Responding or Not")
	void testingMemberPolicy() {
		MemberPolicy memberPolicy = new MemberPolicy("M101", "P1001", 10, "2022/10/06", "2020/10/06");
		assertEquals("M101", memberPolicy.getMemberId());
		assertEquals("P1001", memberPolicy.getPolicyId());
		assertEquals(10, memberPolicy.getTenure());
		assertEquals("2022/10/06", memberPolicy.getPremiumLastDate());
		assertEquals("2020/10/06", memberPolicy.getSubscriptionDate());
	}

}
