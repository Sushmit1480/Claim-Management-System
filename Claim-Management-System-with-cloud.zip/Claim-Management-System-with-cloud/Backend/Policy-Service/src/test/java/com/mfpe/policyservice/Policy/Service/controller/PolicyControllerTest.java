package com.mfpe.policyservice.Policy.Service.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.Set;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.mfpe.policyservice.Policy.Service.exception.InvalidTokenException;
import com.mfpe.policyservice.Policy.Service.feign.AuthClient;
import com.mfpe.policyservice.Policy.Service.service.BenefitsService;
import com.mfpe.policyservice.Policy.Service.service.ClaimAmountService;
import com.mfpe.policyservice.Policy.Service.service.HospitalService;

@SpringBootTest
class PolicyControllerTest {

	@Autowired
	PolicyController policyController;
	
	@MockBean
	AuthClient authClient;
	
	@MockBean
	ClaimAmountService claimAmountService;
	
	@MockBean
	BenefitsService benefitsService;
	
	@MockBean
	HospitalService hospitalService;
	
	@Test
	@DisplayName("Controller Class Loading or Not")
	void test() {
		assertThat(policyController).isNotNull();
	}

	@Test
	@DisplayName("Checking getChainofProviders Endpoint with Invalid Token")
	void testGetChainOfProvidersEndpointWithInvalidToken() {
		String token="MMM";
		when(authClient.authorizeTheRequest(token)).thenReturn(false);
		
		assertThrows(InvalidTokenException.class, () -> policyController.getProviders("P1001", token));
	}
	
	@Test
	@DisplayName("Checking getEligibleBenefits Endpoint with Invalid Token")
	void testGetEligibleBenefitsEndpointWithInvalidToken() {
		String token="MMM";
		when(authClient.authorizeTheRequest(token)).thenReturn(false);
		
		assertThrows(InvalidTokenException.class, () -> policyController.getEligibleBenefits("P1002", "M102", token));
	}
	
	@Test
	@DisplayName("Checking getEligibleClaimAmount Endpoint with Invalid Token")
	void testGetEligibleClaimAmountEndpointWithInvalidToken() {
		String token="MMM";
		when(authClient.authorizeTheRequest(token)).thenReturn(false);
		
		assertThrows(InvalidTokenException.class, () -> policyController.getEligibleAmount("P1003", "M101", token));
	}
	
}
