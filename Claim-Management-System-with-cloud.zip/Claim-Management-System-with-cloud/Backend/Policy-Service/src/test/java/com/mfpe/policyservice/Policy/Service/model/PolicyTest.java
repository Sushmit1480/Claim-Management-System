package com.mfpe.policyservice.Policy.Service.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class PolicyTest {
	
	Policy policy = new Policy();

	@Test
	@DisplayName("Checking Policy is Loading or not")
	void policyIsLoadingOrNot() {
		assertThat(policy).isNotNull();
	}
	
	@Test
	@DisplayName("checking policy class responding or not")
	void testingPolicyClass() {
		Policy policy = new Policy("P1001", "Health", 10000, 5000);
		policy.setPolicyId("P1002");
		policy.setPremium(4000);
		
		assertEquals("P1002", policy.getPolicyId());
		assertEquals(4000, policy.getPremium());
	}

}
