package com.mfpe.Authorizationservice.exception;

@SuppressWarnings("serial")
public class AuthorisationException extends Exception{

	public AuthorisationException(String message) {
		super(message);
	}
	
}
