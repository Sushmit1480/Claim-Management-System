insert into users (id, password, user_name) values (1, 'dummy', 'mohit');
insert into users (id, password, user_name) values (2, 'dummy', 'shatab');
insert into users (id, password, user_name) values (3, 'dummy', 'sushmit');
insert into users (id, password, user_name) values (4, 'dummy', 'anjali');